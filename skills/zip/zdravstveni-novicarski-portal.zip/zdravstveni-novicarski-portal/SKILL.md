---
name: "zdravstveni-novicarski-portal"
description: "Oblikovanje in polnjenje zdravstvenega novičarskega portala (naslovnica z glavno novico, tremi novicami, najbolj brano, rubrikami) z novicami iz izbranega vira, npr. YouTube kanala. Uporabi pri vsaki zdravstveni spletni strani ali portalu."
---

# Zdravstveni novičarski portal

Skill pokriva dve fazi: (1) **ogrodje** – čista, jasna arhitektura novičarske naslovnice o zdravju; (2) **polnjenje** – novice z močnimi, a točnimi naslovi in tematskimi slikami, izhajajoče iz vira, ki ga poda uporabnik (YouTube kanal, podkast, spletna stran, PDF).

Pri pisanju besedil vedno uporabi tudi skill `urednik-novinar-copywriter` (razdelka B in D). Za oblikovanje na platnu (Design artefakt) sledi navodilom tipa artefakta; za samostojno HTML stran skill `spletne-strani`.

---

## 1. Vizualna podoba (privzeta, če uporabnik ne poda drugačne)

Cilj: klinično čisto, zaupanja vredno, časopisno – brez gradientov, emojijev in »AI« trikov.

| Žeton | Vrednost | Raba |
|---|---|---|
| Ozadje | `#FFFFFF` | stran |
| Črnilo | `#13171A` | naslovi, debele črte rubrik (2 px) |
| Besedilo | `#3A444B` | povzetki |
| Sivo (meta) | `#5A646B` | čas, avtor, utility bar |
| Ločnice | `#E3E6E8` | 1 px med bloki |
| Mehka podlaga | `#F2F6F4` | okvir »Vodnik tedna« |
| Prostor za sliko | `#E8EEEC` | placeholder |
| Poudarek | `#0B6E5A` (globoka zelena) | rubrike, aktivni zavihek, gumbi, povezave |
| Alternativni poudarki | `#1D4ED8`, `#B4461E`, `#13171A` | kot tweak |

- **Pisave (Google Fonts):** naslovi `Newsreader` (serif, 500–600), besedilo in UI `Public Sans` (400–700).
- **Velikosti:** H1 glavne novice 48 px / 1.08; naslovi kartic 26 px; seznami 19–22 px; povzetek glavne novice 19 px / 1.55; oznake rubrik 12–13 px, VELIKE ČRKE, razmik 1 px, barva poudarka.
- **Mreža:** vsebina `max-width: 1240px`, robovi 24 px, razmiki med bloki 32–40 px.
- **Odzivnost brez media queryjev:** vrstice so `display:flex; flex-wrap:wrap`; glavni stolpec `flex: 999 1 600px; min-width:0`, stranski `flex: 1 1 300px`, kartice `flex: 1 1 300px` – na telefonu se zložijo v en stolpec.
- **Dostopnost:** prave `<a>`, `<button>`, `<input>` z `<label>`; gumbi ≥ 44 px; kontrast besedila ≥ 4.5:1; slike z `alt`.

## 2. Arhitektura naslovnice (od vrha navzdol)

1. **Utility bar** – datum (dan, datum v slovenščini), O nas, Uredništvo, Kontakt.
2. **Glava** – logotip (ikona: zaobljen kvadrat s križcem v barvi poudarka + ime portala v Newsreader 34 px), iskalnik, gumb »Prijava na novičnik«.
3. **Navigacija rubrik** – zgoraj črta 2 px črnila; rubrike: Najnovejše (aktivna, podčrtana s poudarkom), Medicina, Prehrana, Duševno zdravje, Gibanje, Zdravstveni sistem, Raziskave, Vodniki.
4. **Glavna novica + Najbolj brano** – levo velika slika 16:9, rubrika, H1, povzetek, meta (avtor · čas · čas branja · izhodišče/vir); desno oštevilčen seznam 5 najbolj branih (številke v Newsreader 30 px v barvi poudarka).
5. **Tri novice v vrsti** – slika 3:2, rubrika, naslov, povzetek v eni povedi, meta.
6. **Najnovejše** – seznam z uro objave, rubriko, naslovom in sličico 120×80; desno okvir **Vodnik tedna** (praktičen nasvet + gumb »Preberi vodnik«).
7. **Blok rubrike** (npr. Duševno zdravje) – naslov rubrike in »Vse iz rubrike →«; izpostavljen članek s sliko + 3 naslovi ob strani. Ponovi za druge rubrike.
8. **Novičnik** – temen pas (`#13171A`), naslov, en stavek obljube, polje za e-pošto, gumb.
9. **Noga** – ime portala, opozorilo »Vsebine so informativne narave in ne nadomeščajo nasveta zdravnika ali farmacevta.«, Uredniška načela, Zasebnost, Oglaševanje, Kontakt.

Na Design platnu: en artboard `Main.dc.html`, `w` 1440, `expand: "fill"`, fluiden koren; ponavljajoče se vsebine (najbolj brano, tri novice, najnovejše, rubrika) kot tabele v `renderVals()` in `<sc-for>`; edini tweak je barva poudarka (`accent`, color z možnostmi zgoraj).

## 3. Polnjenje z vsebino iz vira

### 3.1 Raziskava
1. Odpri vir, ki ga poda uporabnik (npr. `youtube.com/@kanal/about`), in ugotovi, kdo ga vodi in o čem govori.
2. Poišči **zadnje objave** (naslovi in datumi): če YouTube ne vrne seznama, poskusi podkast (Apple Podcasts, Spotify), agregatorje statistike kanalov ali spletno iskanje »<ime> video <leto>«.
3. **Preveri verodostojnost vira** (Wikipedia, fact-checki, strokovni odzivi). Zabeleži, katere teme so sporne.

### 3.2 Izbor tem – varovalo za zdravstvene vsebine
- Iz vira prevzemi **teme**, ne nujno trditev. Vsebino napiši po uveljavljenem medicinskem konsenzu (WHO, CDC, NHS, NIJZ, strokovne smernice).
- Teme, pri katerih je vir označen kot zavajajoč (npr. trditve o cepivih, nedokazana zdravila), **ne povzemaj** – ali jih obravnavaj le kritično (»veliko upanja, premalo dokazov«).
- Uporabniku v odgovoru jasno povej, kaj si izpustil in zakaj, ter navedi vire.
- Pri novici, ki izhaja iz konkretnega videa, v meta dodaj »Izhodišče: predavanje/video <avtorja>«.

### 3.3 Naslovi in povzetki
- **Močni naslovi, ki jih besedilo podpira**: dvopičje s kavljem (»Spanec ni razkošje: kaj se zgodi s telesom, ko ga redno zmanjka«), retorično vprašanje (»Antibiotik za prehlad? Zakaj vam ga zdravnik ne bo predpisal«), praktičen kavelj (»Bula pod kožo: kdaj počakati in kdaj takoj k zdravniku«), citat z narekovaji »…«.
- Povzetek: 1–2 povedi s preverjenim dejstvom in koristjo za bralca.
- Brez izmišljenih številk, citatov in imen avtorjev: avtor je »Uredništvo«, manjkajoče označi [PREVERITI].
- Uravnotežena mešanica rubrik: spanec, rak, javno zdravje/pandemije, prehrana, nalezljive bolezni, srce in ožilje, gibanje, zdravila, duševno zdravje.

## 4. Tematske slike

1. **Prednost imajo prave fotografije** z licenco (uporabnikove, Unsplash, Pexels, Wikimedia), naložene kot sredstva artefakta.
2. **Če banke fotografij niso dosegljive**, izdelaj enotne uredniške ilustracije v SVG (Python skript, ki zapiše datoteke) in jih naloži kot sredstva. Slog: ploskovne geometrijske oblike, ena mehka barvna podlaga na temo, črna obroba 10 px pri predmetih, brez besedila. Primeri motivov:
   - spanec – temnomodro nebo, luna, zvezde, postelja;
   - bula/rak – kožna barva, povečevalno steklo;
   - pandemija – zemeljska obla z virusnimi delci;
   - vitamin D – sonce in kapsula;
   - strdki – žila z rdečimi krvničkami in strdkom;
   - gripa – termometer in jesensko listje;
   - gibanje – utež in EKG črta;
   - zdravila – kapsule in bakterije;
   - duševno zdravje – obris glave z valovi.
   Formati: 1600×900 (16:9) za glavno novico in rubriko, 1200×800 (3:2) za kartice in sličice.
3. Pred nalaganjem ilustracije hitro preglej (npr. montaža v PNG), naloži vse v enem klicu in URL-je `/_blob/…` vstavi dobesedno v `<img src>` z opisnim `alt`.
4. Uporabniku povej, kadar so to ilustracije namesto fotografij, in da jih lahko zamenja neposredno na strani.

## 5. Zaključek naloge

V odgovoru (kratko, v slovenščini): kaj je na strani, katere teme iz vira so uporabljene, kaj je izpuščeno in zakaj (uredniška opomba), opomba o slikah, predlog naslednjega koraka (npr. podstran članka z viri in okvirjem »Ključne ugotovitve«) ter seznam »Viri:« s povezavami.